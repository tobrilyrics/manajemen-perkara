```bash
npm i && npm run dev
```
